// src/App.jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import AdminDashboardLayout from './components/layout/AdminDashboardLayout';
import DashboardPage from './pages/admin/DashboardPage';
import UsersManagementPage from './pages/admin/UsersManagementPage';
import PetsManagementPage from './pages/admin/PetsManagementPage';
import ProductsManagementPage from './pages/admin/ProductsManagementPage';
import AppointmentsManagementPage from './pages/admin/AppointmentsManagementPage';
import AdoptionsManagementPage from './pages/admin/AdoptionsManagementPage';
import HealthRecordsPage from './pages/admin/HealthRecordsPage';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/admin/*" element={<AdminDashboardLayout />}>
          <Route index element={<DashboardPage />} />
          <Route path="users" element={<UsersManagementPage />} />
          <Route path="pets" element={<PetsManagementPage />} />
          <Route path="products" element={<ProductsManagementPage />} />
          <Route path="appointments" element={<AppointmentsManagementPage />} />
          <Route path="adoptions" element={<AdoptionsManagementPage />} />
          <Route path="health-records" element={<HealthRecordsPage />} />
        </Route>
        <Route path="*" element={<div className="p-10 text-center">404 - Page Not Found</div>} />
      </Routes>
    </Router>
  );
}

export default App;