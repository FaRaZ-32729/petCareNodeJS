// src/pages/admin/DashboardPage.jsx
import React from 'react';

const DashboardPage = () => {
  // In a real app, you would fetch these stats from your API.
  const stats = [
    { label: 'Total Users', value: '1,234', change: '+12%', icon: '👥' },
    { label: 'Total Pets', value: '892', change: '+5%', icon: '🐾' },
    { label: 'Active Appointments', value: '47', change: '-2%', icon: '📅' },
    { label: 'Products in Catalog', value: '256', change: '+8%', icon: '🛍️' },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6"> {/* Added responsive padding */}
      <h1 className="text-xl sm:text-2xl font-bold text-gray-800">Welcome to FurShield Admin</h1> {/* Responsive font size */}
      
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6"> {/* Unified gap sizing */}
        {stats.map((stat, index) => (
          <div key={index} className="bg-white p-4 sm:p-6 rounded-lg shadow flex items-center"> {/* Responsive padding */}
            <div className="text-2xl sm:text-3xl mr-4">{stat.icon}</div> {/* Responsive icon size */}
            <div>
              <p className="text-xs sm:text-sm text-gray-500">{stat.label}</p> {/* Responsive label font size */}
              <p className="text-xl sm:text-2xl font-bold">{stat.value}</p> {/* Responsive value font size */}
              <p className={`text-xs ${stat.change.startsWith('+') ? 'text-green-500' : 'text-red-500'}`}>
                {stat.change} from last month
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="bg-white p-4 sm:p-6 rounded-lg shadow"> {/* Responsive padding */}
        <h2 className="text-base sm:text-lg font-semibold mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <button className="p-4 border border-gray-300 rounded-lg hover:bg-gray-50 text-left transition duration-200"> {/* Added transition for hover effect */}
            <div className="text-2xl mb-2">➕</div>
            <div className="font-medium">Add New User</div>
          </button>
          <button className="p-4 border border-gray-300 rounded-lg hover:bg-gray-50 text-left transition duration-200">
            <div className="text-2xl mb-2">🐶</div>
            <div className="font-medium">Add New Pet</div>
          </button>
          <button className="p-4 border border-gray-300 rounded-lg hover:bg-gray-50 text-left transition duration-200">
            <div className="text-2xl mb-2">📅</div>
            <div className="font-medium">Schedule Appointment</div>
          </button>
          <button className="p-4 border border-gray-300 rounded-lg hover:bg-gray-50 text-left transition duration-200">
            <div className="text-2xl mb-2">🏠</div>
            <div className="font-medium">New Adoption Listing</div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;